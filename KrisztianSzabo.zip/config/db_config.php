<?php
    $host = '127.0.0.1';
    $db = 'chinook_abridged';
    $username = 'root';
    $password = '';
?>