<?php
    require(__DIR__ . "/header.php");
?>
    <body>
        <h1>Sign up</h1>

        <? require(__DIR__ . "/customer.php"); ?>

        <script src="/js/api.js"></script>
        <script src="/js/signup.js"></script>
    </body>
</html>