<h1>Login</h1>

<label for="email">Email</label>
<input type="email" id="email">
<label for="">Password</label>
<input type="password" id="password">
<div><p id="errorMsg"></p></div>

<button id="btn-login">Submit</button>

<p id="signup">No account? <a href="/signup.php">Sign up!</a></p>

<script src="/js/login.js"></script>